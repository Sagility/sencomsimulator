#include "stdafx.h"
#include "LogJob.h"

using namespace std;

namespace EnergySim { 


	void LogJob::Execute() 
	{
		NotifyJobStarted();
		std::ostringstream strs;
		strs << _ctx->engine()->simulated_time() << " :\t" << _msg << endl;
		_ctx->environment()->Log(strs.str());
		NotifyJobFinished();
	}

}