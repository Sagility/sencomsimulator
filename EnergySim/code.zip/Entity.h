#pragma once
#include <vector>
#include <algorithm>
#include "config.h"
#include "SimLogEnvironment.h"
#include "SimEngine.h"
#include <string>
#include "Job.h"
//#include "CRResource.h"

using namespace std;

namespace EnergySim {
	class IEntity
	{
	public:
		IEntity()
		{
			itsEID = itsUniqueID++;
			itsEntities.push_back(this);
		}
		virtual ~IEntity()
		{
			itsEntities.remove(this);
		}
		long eID() { return itsEID; }
		long itsEID;
		static IEntity* getByID(long theID);
		static long itsUniqueID;
		static list<IEntity*> itsEntities; 
	};

	enum EventType 
	{
		ET_PROCESS_START, ET_PROCESS_END,
		ET_RESOURCE_SETUP_CHANGE, ET_RESOURCE_STATE_CHANGE,
		ET_LOAD_START_STEP, ET_LOAD_END_STEP, ET_LOAD_CREATED, ET_LOAD_FINISHED,
		ET_SIMULATION_START, ET_SIMULATION_END
	};
	enum ResourceState
	{
		RS_WORKING, RS_IDLE, RS_SEARCHING, RS_DOWN, RS_SETUP, RS_LOADING, RS_UNLOADING, RS_STARTING, RS_STARTED
	};
	class ENERGYSIM_DLL_PUBLIC IEvent
	{
	public:
		static void publishEvent(EventType theEventType, long MainID, vector<long> IDs, double Time);
		virtual ~IEvent();
		static void flush();
	private:
		static unsigned _int8* aBuffer;
		static int counter;
		static string fileName;
	};
	class WaitForSetup : public IJob
	{
	public:
		WaitForSetup(long theResID, long theSetup);
		virtual void Execute();
		virtual void Dispose() { }
	private:
		long itsResID;
		long itsSetup;
	};
	class SetState : public IJob
	{
	public:
		SetState(long theResID, ResourceState theState);
		virtual void Execute()
		{
			NotifyJobStarted();
			NotifyJobFinished();
		}
		virtual void Dispose() { }
	private:
		long itsResource;
		ResourceState itsState;
	};
}