#pragma once

#include <iostream>       // std::cout
#include <stack>          // std::stack
#include <vector>         // std::vector
#include <deque>          // std::deque
#include "EnergySim.h"
#include "DateTime.h"
#include "SimEngine.h"
#include "Job.h"
#include <set>
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <type_traits>
#include <functional>
#include "Parsing.h"
#include "Attributes.h"
using namespace std;

namespace EnergySim
{
	class SetAttributeJob : public IJob
	{
	protected:
		MyParser itsParser;
	private: 
		string itsAttribute;
		SimContext itsContext;
		double itsValue;
		AttributeHandler* itsHandler;
	public: 
		SetAttributeJob(AttributeHandler* theHandler, string theAttribute, double theValue)
		{
			itsAttribute = theAttribute;
			itsValue = theValue;
			itsHandler = theHandler;
		}
		virtual void Execute()
		{
			NotifyJobStarted();
			itsHandler->replace(itsAttribute, new ConstantValue(itsValue));
			NotifyJobFinished();
		}
	    virtual void Dispose() { }
	};
	class WaitForAttributeJob : public IJob, public IListenAttributeChange
	{
		AttributeHandler* itsHandler;
		private: double itsLowValue, itsHighValue;
		private: string itsAttribute;
		public: 
			WaitForAttributeJob(AttributeHandler* theHandler, string theAttribute, double theLowValue, double theHighValue)
			{
				itsAttribute = theAttribute;
				itsHighValue = theHighValue;
				itsLowValue = theLowValue;
				itsHandler = theHandler;
			}
			virtual void attributeChanged(string theAttribute, double theValue)
			{
				if (theAttribute == itsAttribute)
					if (theValue<itsHighValue)
						if (theValue>itsLowValue)
						{
							//itsHandler->Changing.erase(std::remove(itsHandler->Changing.begin(), itsHandler->Changing.end(), this));
							NotifyJobFinished();
						}
			}
			virtual void Execute()
			{
				NotifyJobStarted();
				//itsHandler->Changing.push_back(this);
			}
			virtual void Dispose() { }
	};

}