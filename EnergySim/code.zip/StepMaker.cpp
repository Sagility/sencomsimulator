#include "stdafx.h"

#include "SimAdmin.h"
#include <iostream>
#include <string>
#include <fstream>
#include "AttributeJobs.h"
#include "LogJob.h"
#include <regex>


/*
Be able to save values from routefollower to attributes

const std::string DELAYSTEP = "DELAY";						// Time
const std::string WAIT_ATTRIBUTE_STEP = "DELAY";			// ID, v�rde
const std::string PUBLISH_ATTRIBUTE_STEP = "SETATTRIBUTE";		//
const std::string PUBLISH_ROUTEFOLLOWER_TO_ATTRIBUTE_STEP = "SETATTRIBUTE";
const std::string WAIT_SCHEDULE_STEP = "DELAY";
const std::string PUBLISH_SCHEDULE_STEP = "DELAY";
const std::string WAIT_PREREQ_STEP = "DELAY";
const std::string PUBLISH_PREREQ_STEP = "DELAY";
const std::string GET_STEP = "DELAY";
const std::string FREE_STEP = "DELAY";
const std::string STATE_SET = "DELAY";
const std::string WAIT_SETUP_STEP = "DELAY";
const std::string LOGSTEP = "DELAY";
const std::string EVENTSTEP = "DELAY";


ADD WAIT FOR TIME STEP

Order has starttime and ID
*/

namespace EnergySim
{
	Step* StepReader::translateToStep(list<string> arg)
	{
		string aStepName = arg.front();
		arg.pop_front();
		int i, i1,i2 = 0;
		double d1, d2 = 0;
		string str = "";
		if (aStepName == EnergySim_NameConstants::DELAYSTEP)
		{
			if (arg.size() > 0)
				i = stoi(arg.front(), NULL);
			return new DelayStep(i, 0, itsCtx);
		}
		if (aStepName == EnergySim_NameConstants::WAIT_ATTRIBUTE_STEP)
		{
			if (arg.size() > 0)
				str = arg.front();
			arg.pop_front();
			if (arg.size() > 0)
				d1 = stod(arg.front(), NULL);
			arg.pop_front();
			if (arg.size() > 0)
				d2 = stod(arg.front(), NULL);
			return new  WaitStep(str, d1, d2, 0, itsHandler, itsCtx);
		}
		if (aStepName == EnergySim_NameConstants::PUBLISH_ATTRIBUTE_STEP)
		{
			if (arg.size() > 0)
				str = arg.front();
			arg.pop_front();
			if (arg.size() > 0)
				d1 = stod(arg.front(), NULL);
			return new SetStep(str, d1, 0, itsHandler, itsCtx);
		}
		if (aStepName == EnergySim_NameConstants::PUBLISH_ROUTEFOLLOWER_TO_ATTRIBUTE_STEP)
		{
		}
		if (aStepName == EnergySim_NameConstants::WAIT_SCHEDULE_STEP)
		{
			if (arg.size() > 0)
				i1 = stoi(arg.front(), NULL);
			arg.pop_front();
			if (arg.size() > 0)
				i2 = stoi(arg.front(), NULL);
			return new  WaitForScheduleStep(i1, i2, 0, itsCtx, itsSchedule);			
		}
		if (aStepName == EnergySim_NameConstants::PUBLISH_SCHEDULE_STEP)
		{
			if (arg.size() > 0)
				i1 = stoi(arg.front(), NULL);
			arg.pop_front();
			if (arg.size() > 0)
				i2 = stoi(arg.front(), NULL);
			return new  PublishScheduleStep(i1, i2, 0, itsCtx, itsSchedule);
		}
		if (aStepName == EnergySim_NameConstants::WAIT_PREREQ_STEP)
		{
			list<long> aList;
			while (arg.size() > 0)
			{
				i = stoi(arg.front(), NULL);
				aList.push_back(i);
				arg.pop_front();
			}
			return new WaitForPreReqDoneStep(aList, 0, itsCtx);
		}
		if (aStepName == EnergySim_NameConstants::PUBLISH_PREREQ_STEP)
		{
			if (arg.size() > 0)
				i = stoi(arg.front(), NULL);
			return new PublishPreReqDoneStep(i, 0, itsCtx);
		}
		if (aStepName == EnergySim_NameConstants::GET_STEP)
		{

		}
		if (aStepName == EnergySim_NameConstants::FREE_STEP)
		{

		}
		if (aStepName == EnergySim_NameConstants::STATE_SET)
		{

		}
		if (aStepName == EnergySim_NameConstants::WAIT_SETUP_STEP)
		{

		}
		if (aStepName == EnergySim_NameConstants::LOGSTEP)
		{
			if (arg.size() > 0)
				str = arg.front();
			return new LogStep(str, 0, itsCtx);
		}
		if (aStepName == EnergySim_NameConstants::EVENTSTEP)
		{
		}

		return NULL;
	}

}