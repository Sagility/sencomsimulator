// EnergySim.h

#pragma once
#include "config.h"
#include "SimEngine.h"
using namespace std;

namespace EnergySim {

	// forward declarations
	class SimContext; 

	class ENERGYSIM_DLL_PUBLIC SimModel
	{
	private:
		SimContext* _ctx;

	public:
		//constructor
		SimModel(SimContext* ctx){_ctx=ctx;}

		SimContext* context() const{ return _ctx;}
	
	};

};