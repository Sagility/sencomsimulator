#include "stdafx.h"
#include "DelayJob.h"

using namespace std;

namespace EnergySim { 


	void DelayJob::Execute() 
	{
		NotifyJobStarted();
		if (delay > 0)
		{
			_timer->AddElapsedListener(this);
			_timer->AddPreemptedListener(this);
			_timer->Start();
		}
		else DelayElapsed();
	}


	 void DelayJob::OnElapsed(ITimer *theTimer, EventArgs *theArgs)
	 {
		 DelayElapsed();
	 }
	 void DelayJob::OnPreempted(ITimer *theTimer, EventArgs *theArgs)
	 {
		 Preempt();
	 }

}