
#include "stdafx.h"
#include<iostream>
#include "SimLogEnvironment.h"
#include "EnergySim.h"
#include "SimEngine.h"
#include "CombinedJobController.h"
#include "LogJob.h"
#include "DelayJob.h";
#include "ClaimRelease.h"
//#include "Parsing.h"
#include "Schedule.h"


namespace EnergySim
{
	void Schedule::markJobAsStarted(long lotID, long stepID)
	{
		pair<long, long> *aJob = new pair<long, long>(lotID, stepID);
		pair<double, pair<long, long>> *aPP = new pair<double, pair<long, long>>(300.0, *aJob);
		
		
		//aPP.Key=itsContext.Engine.SimulatedTime;
		//aPP.Value = aJob;

		//
		itsOutSchedule->push_back(*aPP);
		for (SchedElement *aSE : *itsInSchedule)
		{
			if (aJob->first == aSE->lotID)
			if (aJob->second == aSE->stepID)
			{
				//TODO itsInSchedule->Remove(aSE);
				break;
			}
		}

		bool keepGoing = true;
		while (keepGoing)
		{
			keepGoing = false;
			for (WaitForScheduleJob* j : *itsWaiters)
			{
				if (canIStart(j->itsLotID, j->itsStepID))
				{
					j->finish();
					//TODO	itsWaiters->Remove(j);
					keepGoing = true;
					break;
				}
			}
		}
		// Publish an update
	}


}