// SchedulableEvent.h

#pragma once
#include "EnergySim.h"
#include <vector>
#include <list>
#include <algorithm>
#include "Job.h"
#include "ClaimRelease.h"
using namespace std;

namespace EnergySim
{
	
	class SimResourcen;
	
	class Capacity
	{


	};

	class IOperationModeNeed
	{

	};

	class IRules{};

	template<class C, class D> class Rules :public IRules
	{
	public:
		virtual C getCapacity() = 0;

	};


	class MyFactory : public Rules<Capacity, Capacity>
	{
		public:
			Capacity getCapacity()
			{
				return Capacity();
			}
	};



	template<class C> class OperationModeNeed : public IOperationModeNeed
	{


	};

	class Test
	{
	public:
		Test()
		{
		}
	};

	class Operation
	{
		public:

		private:

	};


	class OperationMode
	{
		public: 
			virtual void preReq();
			virtual void start();
			virtual void finish();
			virtual IJob* getJob();
			virtual void start();
			virtual void doFullOperationMode();
			// Set value
		protected:
			virtual void releaseAll();
		private:
			Operation* itsOperation;
			list<IOperationModeNeed*> itsNeed;
			list<Capacity*> itsClaimed;
	};

	template<class C> class ENERGYSIM_DLL_PUBLIC SimResource
	{
	public:
		template<class D> class contained : public D
		{

		};
		contained<C> first;
		contained<C> second;

		virtual void OnEvent(ISimEngine *theEngine, EventArgs *theArgs) = 0;
	};


}