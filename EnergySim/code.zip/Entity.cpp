#include "stdafx.h"
//#include "Entity.h"
#include <memory>
#include <vector>
#include <stdio.h>
#include <string.h>
#include "Entity.h"
#include "CRResource.h"

using namespace std;

namespace EnergySim
{
	
	list<IEntity*> IEntity::itsEntities = list<IEntity*>();

	IEntity* IEntity::getByID(long theID)
	{
		for (IEntity* aIE : itsEntities)
			if (aIE->itsEID == theID)
				return aIE;
		return NULL;
	}
	void IEvent::flush()
	{
		if (counter < 1)
			return;
		FILE* pFile;
		pFile = fopen(fileName.c_str(), "ab");
		fwrite(aBuffer, 1, counter, pFile);
		fclose(pFile);
		counter = 0;
	}
	IEvent::~IEvent() {}
	unsigned _int8* IEvent::aBuffer = (unsigned _int8*) malloc(1100000);
	int IEvent::counter = 0;
	string IEvent::fileName = "buffer.abc";
	void IEvent::publishEvent(EventType theEventType, long MainID, vector<long> IDs, double Time)
	{
		unsigned _int8 * aPtr = aBuffer;
		long aTmp = IDs.size();

		// Must add time stamp
		aPtr += counter;
		_memccpy(aPtr, &aTmp, 1, 4);
		aPtr += 4;
		_memccpy(aPtr, &theEventType, 1, sizeof(EventType));
		aPtr += 4;
		_memccpy(aPtr, &MainID, 1, 4);
		aPtr += 4;
		if (IDs.size()<0)
		{
			_memccpy(aPtr, &IDs, 1, 4 * IDs.size());
			aPtr += IDs.size() * 4;
		}
		_memccpy(aPtr, &Time, 1, 8);
		aPtr += 8;
		counter += IDs.size() * 4 + 20; //TODO Seems to be bug, use aPtr, use sizeof of long
		if (counter > 900000)
			flush();
	}

	void WaitForSetup::Execute()
	{
			NotifyJobStarted();
			IEntity* aIE = IEntity::getByID(itsResID);
			Resource* aR = dynamic_cast<Resource*>(aIE);
			if (aR != NULL)
			{
				if (itsSetup != aR->setup())
				{


				}
			}
			NotifyJobFinished();
		}
}


