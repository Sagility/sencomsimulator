// LogJob.h

#pragma once

#include <vector>
#include <algorithm>
#include <sstream>
#include "config.h"
#include "Job.h"
#include "SimEngineTimer.h"

using namespace std;

namespace EnergySim {
	// Forward declarations
	class SimEngineTimer;
	class SimContext;

	class ENERGYSIM_DLL_PUBLIC LogJob: public IJob
    {

	private: 
		string _msg;
	public:
		//constructor
		LogJob(SimContext *context, string msg):IJob(context)
        {
                set_context(context);
                _msg = msg;
        }
		~LogJob()
		{
			// clear all lists
		}

		virtual string ToString()
		{
			return "LogJob logging " + _msg +"\n";
		}

		virtual void Execute(); 
		 virtual string classname() { return "LogJob";}
    };
}