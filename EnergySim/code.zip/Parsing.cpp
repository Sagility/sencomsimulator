#include "Stdafx.h"
#include "Parsing.h"
#include <iostream>
#include <string>
#include <regex>
#include "Attributes.h"

using namespace std;

namespace EnergySim
{
	MyParser::MyParser()
	{
		aAH = new AttributeHandler();
	}
	MyParser::MyParser(AttributeHandler* theHandler)
	{
		aAH = theHandler;
	}
	void MyParser::addAttribute(string theExpression, string theName)
	{
		itsStr = theExpression;
		Tokenize();
		Parse();
		while (!func.empty())
			popOneAction();
		if (aAH == NULL)
			aAH = new AttributeHandler();
		aAH->addAttribute(dst.top().itsBV, theName);
		return;
	}
	BaseAttributeValueHolder* MyParser::parse(string theExpression, string theName)
	{
		
		itsStr = theExpression;
		Tokenize();
		Parse();
		while (!func.empty())
			popOneAction();
		BaseAttributeValueHolder* aBVAH = new BaseAttributeValueHolder(dst.top().itsBV, theName);
		return aBVAH;
	}
	void MyParser::test(string aStr)
	{
		addAttribute("2*a+b", "c");
		addAttribute("switch(1,1,1)", "b");
		addAttribute("(lessthan(checkone(2,3,4),40)*(2-3)) + 45*10-(2-3*checkone(2,3,4)+4) + checkone(2) -checkone()", "a");



		string aALL = aAH->getAllAttributes();
		std::cout << aALL << std::endl;
		//aAH->replace();

		return;
		aAH = new AttributeHandler();
		aStr = "(lessthan(checkone(2,3,4),40)*(2-3)) + 45*10-(2-3*checkone(2,3,4)+4) + checkone(2) -checkone()";

		itsStr = aStr;
		Tokenize();
		//std::cout << "Tokens in " << itsStr << ":";

        Parse();
		while (!func.empty() )
		{
			popOneAction();
		}
		int i = dst.size();
		double aD = dst.top().itsBV->value();
		
		aAH->addAttribute(dst.top().itsBV, "a");
		itsStr = "a+100";
		Tokenize();
		Parse();
		while (!func.empty())
			popOneAction();
		aAH->addAttribute(dst.top().itsBV, "b");
		string test = aAH->getAllAttributes();


		std::cout << "End tokens.";
	}
	void MyParser::Tokenize()
	{
		while (!src.empty())
			src.pop();
		while (!dst.empty())
			dst.pop();
		while (!func.empty())
			func.pop();

		string s = itsStr;
		smatch m;
		regex e("[a-z]+|[0-9.]+|[(]|[)]|[+]|[-]|[*]|[/]|[ ]|[,]");

		while (regex_search(s, m, e)) 
		{
			for (auto x : m)
			{
				MyParserAction aM = MyParserAction();
				aM.itsFunction = Function::EMPTY;
				
				string aStr = x;
				char aC = aStr[0];
				std::cout << x << " ";
				aM.itsValue = aStr;
				switch (aC)
				{

					case '+': aM.itsFunction = Function::ADD; break;
					case '-': aM.itsFunction = Function::SUB; break;
					case '/': aM.itsFunction = Function::DIV; break;
					case '*': aM.itsFunction = Function::MUL; break;
					case '(': aM.itsFunction = Function::LP; break;
					case ')': aM.itsFunction = Function::RP; break;
					case ',': aM.itsFunction = Function::COMMA; break;
					case ' ': aM.itsFunction = Function::EMPTY; break;

					 default: 
						 // This is a number or a name or empty
						 if (aC< '9' && aC > '0')
						 {
							 aM.itsFunction = Function::VALUE;
							 aM.itsValue = aStr;
						 }
						 else
						 {
							 aM.itsFunction = Function::NAME;
							 aM.itsValue = aStr;
						 }
						 break;
				}
				if (aM.itsFunction != Function::EMPTY)
					dst.push(aM);
			}
			std::cout << std::endl;
			s = m.suffix().str();
		}

		while (!dst.empty())
		{
			src.push(dst.top());
			dst.pop();
		}
		return;
	}
	void MyParser::popOneAction()
	{
		if (func.empty())
			return;
		if (func.top().itsFunction == LP)
			return;
		if (func.top().itsFunction == NAME)
		{
			MyParserAction aMPA = dst.top();
			dst.pop();
			MyParserAction bMPA = func.top();
			func.pop();
			aMPA.itsBV = new FunctionValue(aMPA.itsBV, bMPA.itsValue); // SHOULD BE A FUNCTION, LOOK BY NAME
			aMPA.itsFunction = VALUE;
			dst.push(aMPA);
			return;
		}
		if (!func.empty())
		{
			MyParserAction bMPA = dst.top();
			dst.pop();
			MyParserAction aMPA = dst.top();
			dst.pop();
			MyParserAction cMPA = func.top();
			func.pop();
			switch (cMPA.itsFunction)
			{
				case ADD: 
					cMPA.itsBV = new AdditionValue(aMPA.itsBV, bMPA.itsBV);
					break;
				case SUB:
					cMPA.itsBV = new SubstractionValue(aMPA.itsBV, bMPA.itsBV);
					break;
				case DIV:
					cMPA.itsBV = new DivisionValue(aMPA.itsBV, bMPA.itsBV);
					break;
				case MUL:
					cMPA.itsBV = new MultiplicationValue(aMPA.itsBV, bMPA.itsBV);
					break;
				case COMMA:
					cMPA.itsBV = new ListValue(aMPA.itsBV, bMPA.itsBV);
					dst.push(cMPA);
					if (!func.empty() && func.top().itsFunction == COMMA)
						popOneAction();
					return;
					break;
				case LP: ; break;
				case RP: ; break;
				default:
					break;
			}
			dst.push(cMPA);
		}
	}
	void MyParser::Parse()
	{
		while (!src.empty())
		{
			MyParserAction aMPA = src.top();
			src.pop();
			if (aMPA.itsFunction == VALUE)
			{
				string aStr = aMPA.itsValue;
				double aD = std::atof(aStr.c_str());
				aMPA.itsBV = new ConstantValue(aD);
				dst.push(aMPA);
				continue;
			}
			if (aMPA.itsFunction < Function::LP)
			{
				while (!func.empty() && dst.size()>1 && func.top().itsFunction!=LP)
				{
					if (aMPA.itsFunction == ADD || aMPA.itsFunction == SUB)
					{
						popOneAction();
						continue;
					}
					if (func.top().itsFunction == MUL || func.top().itsFunction == DIV)
					{
						popOneAction();
						continue;
					}
					break;
				}
				func.push(aMPA);
			}
			if (aMPA.itsFunction == Function::LP)
			{
				func.push(aMPA);
				if (!src.empty() && src.top().itsFunction == Function::RP)
				{
					MyParserAction emptyMPA = MyParserAction();
					emptyMPA.itsFunction = Function::VALUE;
					emptyMPA.itsBV = new ConstantValue(0);
					dst.push(emptyMPA);
				}
			}
			if (aMPA.itsFunction == Function::COMMA)
			{
				func.push(aMPA);
			}
			if (aMPA.itsFunction == Function::NAME)
			{
				if (!src.empty() && (src.top().itsFunction == Function::LP))
					func.push(aMPA);
				else
				{
					aMPA.itsBV = new AttributeLookUpValue(aMPA.itsValue, aAH);
					dst.push(aMPA);
				}					
			}
			if (aMPA.itsFunction == Function::RP)
			{
				while (!func.empty() && func.top().itsFunction != Function::LP)
				{
					popOneAction();
				}
				aMPA = func.top();
				func.pop();
				if (!func.empty())
				{
					if (func.top().itsFunction == Function::NAME)
					{
						//  is a function call
						//  Function::COMMA
						aMPA = func.top();
						func.pop();

						MyParserAction bMPA = dst.top();
						dst.pop();

						aMPA.itsBV = new FunctionValue(bMPA.itsBV, aMPA.itsValue); // SHOULD BE A FUNCTION, LOOK BY NAME
						aMPA.itsFunction = VALUE;
						dst.push(aMPA);
						// Arguments are ina list on the dst
					}
				}
			}
		}
	}
}