// config.h
#pragma once

#define ENERGYSIM_DLL_EXPORT __declspec(dllexport)
#define ENERGYSIM_DLL_IMPORT __declspec(dllimport)

// Should be defined when MyDLL is built (more details below).
#ifdef ENERGYSIM_DLL_EXPORTS
  #define ENERGYSIM_DLL_PUBLIC ENERGYSIM_DLL_EXPORT
#else
  #define ENERGYSIM_DLL_PUBLIC ENERGYSIM_DLL_IMPORT
#endif

#define ENERGYSIM_DLL_PRIVATE

#ifdef __cplusplus
  #define ENERGYSIM_DLL_FUNCTION extern "C"
#else
  #define ENERGYSIM_DLL_FUNCTION extern
#endif