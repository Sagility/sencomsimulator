#include "Stdafx.h"
#include "ClaimRelease.h"
#include "CRResource.h"

namespace EnergySim
{
	WaitForResources::WaitForResources(long theProcessID)
	{
		Process*	itsResReq = dynamic_cast<Process*> (IEntity::getByID(theProcessID));
	}

	long IEntity::itsUniqueID = 1000;

	bool ResourceHandler::assignJob()
	{
		return true;
	}
	//Procesa	;

	void IJobAssigner::assignAJob(WaitForResources* aWFR, list<Resource*>* aRL)
	{
		//if (aWFR->Dispose.Finish);//
		//aWFR->claimer
		//for Asd = ;
		//
	}
	
	bool isEmpty(Resource* r) { if (r->free() < 1) return true; return false; }

	bool byClaimer(pair<WaitForResources*, Process*> a, pair<WaitForResources*, Process*> b)
	{
		if (a.first->claimer()->ID() > b.first->claimer()->ID())
			return true;
		return false;
	}

	bool shouldWork(Resource* r1, Resource* r2) 
	{
		return true;
	}

	bool TestJobAssigner::assignJob()
	{
		// Assign according to prio of claimers
		// Assign according to largest job first
		// Assign according to prio of resource
		// Assign according to schedule

		list<Resource*> aRL = resources();
		aRL.remove_if(isEmpty);
		aRL.sort(shouldWork);
	//	list<list<Resource*>>
		list<pair<WaitForResources*, Process*>> aResReg = resReg();
		aResReg.sort(byClaimer);

		WaitForResources* aWFR = NULL;
		list<Resource*>* aCRL =  new list<Resource*>();

		// 

		if (aWFR == NULL)
			return false;
		assignAJob(aWFR, aCRL);
		return true;
	};


	IJob* ResourceHandler::getResources(list< list<Resource*> > theResReq, IClaimer<long>* theClaimer)
	{
		return NULL;
	}





}