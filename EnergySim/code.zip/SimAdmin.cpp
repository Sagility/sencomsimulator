#include "stdafx.h"

#include "SimAdmin.h"
#include <iostream>
#include <fstream>
#include "AttributeJobs.h"
#include "LogJob.h"
#include <regex>




namespace EnergySim
{
	void PublishPreReqDoneStep::generateSpecificJobs(CombinedJobController theController)
	{
		theController.AddJob(new PublishPreReqDone(itsPreReqDone));
	}
	void WaitForPreReqDoneStep::generateSpecificJobs(CombinedJobController theController)
	{
		theController.AddJob(new WaitForPreReqDoneJob(itsPreReqNeed));
	}
	void WaitForScheduleStep::generateSpecificJobs(CombinedJobController theController)
	{
		theController.AddJob(new WaitForScheduleJob(itsSchedule, itsLotID, itsStepID));
	}
	void PublishScheduleStep::generateSpecificJobs(CombinedJobController theController)
	{
		theController.AddJob(new PublishScheduleJob(itsSchedule, itsLotID, itsStepID));
	}
	Step* StepReader::readLine(string str)
	{
		const std::string s = "DELAY   45 brown fox.";

		std::regex words_regex("[^\\s]+");
		auto words_begin =
			std::sregex_iterator(s.begin(), s.end(), words_regex);
		auto words_end = std::sregex_iterator();

		list<string> stepArguments;
		int length = std::distance(words_begin, words_end);
		for (std::sregex_iterator i = words_begin; i != words_end; ++i) {
			std::smatch match = *i;
			std::string match_str = match.str();
			stepArguments.push_back(match_str);
		}
		if (stepArguments.size() < 1)
			return NULL;
		return translateToStep(stepArguments);
	}

	Buffer* SimAdmin::getBufferByID(long id)
	{
		for (Buffer *b : *itsBuffers)
//TODO		if (b->id == id)
//TODO			return b;
		return NULL;
	}
	void Step::generateJobs(Schedule* theS, CombinedJobController theController, long lotID)
	{
		//TODO theController.AddJob(new LogJob(itsContext, lotID, itsID, true));
		theController.AddJob(new WaitForScheduleJob(theS, lotID, itsID));
		generateSpecificJobs(theController);
		theController.AddJob(new PublishScheduleJob(theS, lotID, itsID));
		//TODO theController.AddJob(new LogJob(itsContext, lotID, itsID, false));
	}

	long SimAdmin::runModel()
	{
		/*

		// Create environment for logging
		SimEnvironment.CurrentEnvironment = SimLogEnvironment.CreateEnvironment();
		SimEnvironment.CurrentEnvironment.Debug = true;
		SimEnvironment.CurrentEnvironment.Log("SencomSimTest: Start testing");
		// create model
		SencomModel model = SencomModel.instance();
		SimEnvironment.CurrentEnvironment.Log("SencomSimTest: Created model");
		//create context

		Context->model = model;
		SimEnvironment.CurrentEnvironment.Log("SencomSimTest: Created context");
		Context->engine = new SimEngine(Context);
		SimEnvironment.CurrentEnvironment.Log("SencomSimTest: Created context with engine");


		*/



		// Create attribute stuff

		// TODO this->Context->engine->scheduler.itsParser = new MyParser();


		//    this.Context.Engine.scheduler.itsParser.readParseExpressionAttribute("d	3	d+3");
		//  this.Context.Engine.scheduler.itsParser.readParseExpressionAttribute("e	9	e+0");
		list<CombinedJobController> *aController = new list<CombinedJobController>();

		for (Order *o : *itsOrders)
		{
			CombinedJobController *aCJC = new CombinedJobController(Context, "o->ID");
			for (Route *r : *itsRoutes)
			{
				if (r->name != o->Route)
					continue;
				r->createThisJobOrder(aScheduler, *o, *aCJC);
				aController->push_back(*aCJC);
				break;
			}
		}

		// TODO Below
		//for (CombinedJobController c : *aController)
		//	Context->engine.InvokeJob(c);

		//Context->engine->Run();
		aScheduler->finish();
		//SencomSimTest.instance().Run();
		return 0;
	}

	void SimAdmin::readRoute(string filename, string theName)
	{
		Route* aRoute = new Route();
		aRoute->name = theName;
		std::ifstream file(filename);
		std::string line;
		StepReader aSR;
		while (std::getline(file, line))
		{
			Step* aStep = aSR.readLine(line);
			aRoute->addStep(aStep);
		}
		itsRoutes->push_back(aRoute);
	}


}
#ifdef NNNNNN

	void SimAdmin::readDemand(string filename)
	{
		string line;
		System.IO.StreamReader file = new System.IO.StreamReader(filename);
		while ((line = file.ReadLine()) != null)
		{
			long itsBufferID = 0;
			double itsDesiredLevel;
			MatchCollection aMC = Regex.Matches(line, "[0-9]+");
			if (aMC.Count > 1)
				itsBufferID = Convert.ToInt64(aMC[0].Value);
			else
				continue;
			aMC = Regex.Matches(line, "[0-9]+[,]?[0-9]*");
			if (aMC.Count > 1)
			{
				itsDesiredLevel = Convert.ToDouble(aMC[1].Value);
			}
			else
				continue;

			BufferDemand aBD = new BufferDemand(getBufferByID(itsBufferID), itsDesiredLevel);
			itsDemands.Add(aBD);
		}
	}
	void SimAdmin::readProcess(string filename)
	{
		string line;
		System.IO.StreamReader file = new System.IO.StreamReader(filename);
		while ((line = file.ReadLine()) != null)
		{
			long aID = 0;
			List<Rate> aConsume = new List<Rate>();
			List<Rate> aProduce = new List<Rate>();
			Rate aR = null;
			double aSelfSpeed = 0;
			MatchCollection aMC = Regex.Matches(line, "[0-9]+");
			if (aMC.Count > 1)
				aID = Convert.ToInt64(aMC[0].Value);
			else
				continue;

			aMC = Regex.Matches(line, "(IN)");
			string aTmp = line.Remove(0, aMC[0].Index + 2);
			aMC = Regex.Matches(aTmp, "(OUT)");
			aTmp = aTmp.Remove(aMC[0].Index);
			aMC = Regex.Matches(aTmp, "[0-9]+[,]?[0-9]*");
			int i = 0;
			while (aMC.Count > i + 1)
			{
				Buffer aB = null;
				long aComp = Convert.ToInt64(aMC[i].Value);
				foreach(Buffer b in itsBuffers)
				if (b.id == aComp)
					aB = b;
				aR = new Rate(aB, Convert.ToDouble(aMC[i + 1].Value));
				aConsume.Add(aR);
				i = i + 2;
			}
			aMC = Regex.Matches(line, "(OUT)");
			aTmp = line.Remove(0, aMC[0].Index + 3);
			aMC = Regex.Matches(aTmp, "SELF");
			aTmp = aTmp.Remove(aMC[0].Index);
			aMC = Regex.Matches(aTmp, "[0-9]+[,]?[0-9]*");
			i = 0;
			while (aMC.Count > i + 1)
			{
				Buffer aB = null;
				long aComp = Convert.ToInt64(aMC[0 + i].Value);
				foreach(Buffer b in itsBuffers)
				if (b.id == aComp)
					aB = b;
				aR = new Rate(aB, Convert.ToDouble(aMC[1 + i].Value));
				aProduce.Add(aR);
				i = i + 2;
			}
			aMC = Regex.Matches(line, "[0-9]+[,]?[0-9]*");
			if (aMC.Count > 0)
				aSelfSpeed = Convert.ToDouble(aMC[aMC.Count - 1].Value);
			else
				continue;
			Process aP = new Process(aConsume, aProduce, aSelfSpeed, aID);
			itsProcess.Add(aP);
		}
	}



	void SimAdmin::readBuffers(string filename)
	{
		string line;
		System.IO.StreamReader file = new System.IO.StreamReader(filename);
		while ((line = file.ReadLine()) != null)
		{
			long aID = 0;
			bool aDiscrete = false;
			double aLevel = 0;
			double aMaxLevel = 0;
			MatchCollection aMC = Regex.Matches(line, "[0-9]+");
			if (aMC.Count > 0)
				aID = Convert.ToInt64(aMC[0].Value);
			else
				continue;
			aMC = Regex.Matches(line, "[a-z]+");
			if (aMC.Count > 0)
				aDiscrete = Convert.ToBoolean(aMC[0].Value);
			else
				continue;
			aMC = Regex.Matches(line, "[0-9]+[,]?[0-9]*");
			if (aMC.Count > 1)
			{
				aLevel = Convert.ToDouble(aMC[0].Value);
				aMaxLevel = Convert.ToDouble(aMC[1].Value);
			}
			else
				continue;
			itsBuffers.Add(new Buffer(aMaxLevel, aLevel, aDiscrete, aID));
		}
	}
	void SimAdmin::readOrders(string filename)
	{
		string line;
		int aTmpID = 10;
		System.IO.StreamReader file = new System.IO.StreamReader(filename);
		while ((line = file.ReadLine()) != null)
		{
			long id = -1;
			long time = 0;
			MatchCollection aMC = Regex.Matches(line, "[0-9]+");
			if (aMC.Count == 2)
			{
				id = Convert.ToInt64(aMC[0].Value);
				time = Convert.ToInt64(aMC[1].Value);
			}
			Match aM = Regex.Match(line, "[a-z]+");
			if (aM.Success)
			{
				if (id > -1)
				{
					Order aO = new Order();
					aO.ID = id;
					aO.Route = aM.Value;
					aO.Time = time;
					if (true)
						itsOrders.Add(aO);
					else
					for (int i = 0; i < 100; i++)
					{
						//itsOrders.Add(aO);
						aO.ID = aTmpID++;
						itsOrders.Add(aO);
					}
				}
			}
		}
		file.Close();
	}
	void SimAdmin::readResources(string filename)
	{
		string line;
		System.IO.StreamReader file = new System.IO.StreamReader(filename);
		while ((line = file.ReadLine()) != null)
		{
			Console.WriteLine(line);
			MatchCollection aMC = Regex.Matches(line, "[0-9]+");
			if (aMC.Count == 2)
			{
				long res = Convert.ToInt64(aMC[0].Value);
				long cap = Convert.ToInt64(aMC[1].Value);
				itsRes.Add(res, cap);
			}
		}
		file.Close();
	}
	void SimAdmin::readRoutes(string filename)
	{
		string[] filePaths = Directory.GetFiles(Directory.GetCurrentDirectory(), filename + "*.route");
		foreach(string s in filePaths)
		{
			string aRouteName = s.Remove(s.Length - 6);
			aRouteName = aRouteName.Remove(0, Directory.GetCurrentDirectory().Length + 1);
			readRoute(s, aRouteName);

		}
		//readRoute(filename + ".route");
		//readRoute(filename + "aa.route");
	}
	void SimAdmin::readRoute(string filename, string theName)
	{
		Route aRoute = new Route();
		aRoute.name = theName;
		string line;
		System.IO.StreamReader file = new System.IO.StreamReader(filename);
		long id = 1;
		while ((line = file.ReadLine()) != null)
		{
			Match aM = Regex.Match(line, "[0-9]+");
			id = Convert.ToInt64(aM.Value);
			line = line.Remove(0, aM.Value.Length);
			aM = Regex.Match(line, "GET|FREE|DELAY|SET|WAIT");
			Step aStep = null;
			if (aM.Success)
			{
				string tmp = aM.Value;
				switch (tmp)
				{
				case "GET":
					aM = Regex.Match(line, "[0-9]+");
					if (aM.Success)
					{
						long aRes = Convert.ToInt64(aM.Value);
						aStep = new GetStep(aRes, id, Context);
					}
					break;
				case "FREE":
					aM = Regex.Match(line, "[0-9]+");
					if (aM.Success)
					{
						long aRes = Convert.ToInt64(aM.Value);
						aStep = new FreeStep(aRes, id, Context);
					}
					break;
				case "DELAY":
					aM = Regex.Match(line, "[0-9]+");
					if (aM.Success)
					{
						long aDelay = Convert.ToInt64(aM.Value);
						aStep = new DelayStep(aDelay, id, Context);
					}
					break;
				case "SET":
					line = line.Replace("SET", "");
					aM = Regex.Match(line, "[a-z]+");
					if (aM.Success)
					{
						string name = aM.Value;
						line = line.Replace(name, "");
						double value = Convert.ToDouble(line.Trim());
						aStep = new SetStep(name, value, id, itsHandler, Context);
					}
					break;
				case "WAIT":
					line = line.Replace("WAIT", "");
					aM = Regex.Match(line, "[a-z]+");
					if (aM.Success)
					{
						string name = aM.Value;
						line = line.Replace(name, "");
						MatchCollection aMC = Regex.Matches(line, "-?[0-9]+");
						if (aMC.Count == 2)
						{
							double lowValue = Convert.ToDouble(aMC[0].Value);
							double highValue = Convert.ToDouble(aMC[1].Value);
							aStep = new WaitStep(name, lowValue, highValue, id, itsHandler, Context);
						}
					}
					break;
				}
				if (aStep != null)
				{
					//id++;
					aRoute.addStep(aStep);
				}
			}
		}
		file.Close();
		itsRoutes.Add(aRoute);
	}
	void SimAdmin::readFunctionAttributes(string filename)
	{
		MyParser aP = new MyParser(itsHandler);
		string line;
		System.IO.StreamReader file = new System.IO.StreamReader(filename);
		while ((line = file.ReadLine()) != null)
		{
			aP.readParseFunctionAttribute(line);
		}
		file.Close();
	}
	void SimAdmin::readExpressionAttributes(string filename)
	{
		MyParser aP = new MyParser(itsHandler);
		string line;
		System.IO.StreamReader file = new System.IO.StreamReader(filename);
		while ((line = file.ReadLine()) != null)
		{
			aP.readParseExpressionAttribute(line);
		}
		file.Close();
	}
	void SimAdmin::readSchedule(string filename)
	{
		string line;
		System.IO.StreamReader file = new System.IO.StreamReader(filename);
		while ((line = file.ReadLine()) != null)
		{
			Console.WriteLine(line);
			MatchCollection aMC = Regex.Matches(line, "[0-9]+");
			if (aMC.Count > 2)
			{
				long lotID = Convert.ToInt64(aMC[0].Value);
				long stepID = Convert.ToInt64(aMC[1].Value);
				long time = Convert.ToInt64(aMC[2].Value);
				aScheduler.addJob(lotID, stepID, time);
			}
		}
		file.Close();
	}





}

#endif //#ifdef NNNNNN