#pragma once

#include <vector>
#include <map>
#include <algorithm>
#include <sstream>
#include "config.h"
#include "Job.h"
#include "SimEngineTimer.h"
#include "TimeValues.h"
#include <list>
#include "ClaimRelease.h"
#include "Entity.h"

using namespace std;

namespace EnergySim 
{
	class Resource;
	class Process;
	class ConcreteProcess;
	class WaitForResources : public IJob
	{
		public:
			WaitForResources(long theProcessID);
			virtual void attributeChanged(string theAttribute, double theValue)
			{
					NotifyJobFinished();
			}
			virtual void Execute()
			{
				NotifyJobStarted();
			}
			virtual void Dispose() { }
			IClaimer<long>* claimer() { return itsClaimer; }
		private:
			void claimResources();
			
			Process* itsResReq;
			IClaimer<long>* itsClaimer;
	};

	class ResourceHandler
	{
	public:
		IJob* getResources(list< list<Resource*> > theResReq, IClaimer<long>* theClaimer);
		bool assignJob();
		friend class IJobAssigner;
	protected:
		list<Resource*> itsResources;
		list<pair<WaitForResources*, Process*>> itsResReq;
		list<Process*> waiting;
		// list<Process*> waiting;
		list<long> doneProcess;
	};

	class IJobAssigner
	{
	public:
		IJobAssigner(ResourceHandler* theRH){ itsRH = theRH; }
		virtual bool assignJob()= 0;
	protected:
		list<Resource*> resources() { return itsRH->itsResources; }
		ResourceHandler* itsRH;
		list<pair<WaitForResources*, Process*>> resReg() { return itsRH->itsResReq; }
		void assignAJob(WaitForResources* aWFR,	list<Resource*>* aRL );
	};

	class TestJobAssigner : public IJobAssigner
	{
	public:
		TestJobAssigner(ResourceHandler* theRH) : IJobAssigner(theRH){}
		virtual bool assignJob();
	//protected:
		bool IsOdd(Resource* r) { return true; }
	};
	
	class IEntity;
	class Resource : public IEntity,  protected ClaimReleaseResourceHandler<long>
	{
	public:
		Resource(IClock* theClock) : itsCapacity(0, theClock), itsUsedCapacity(0, theClock)
		{}
		int capacity() { return itsCapacity.getValue(); }
		int free(){ return itsCapacity.getValue() - itsUsedCapacity.getValue(); }
		void get(IClaimer<long>* theClaimer, long neededCapacity)
		{
			itsUsedCapacity = itsUsedCapacity + neededCapacity;
			itsClaimers.push_back(pair<IClaimer<long>*, int>(theClaimer, neededCapacity));
		}
		void free(IClaimer<long>* theClaimer)
		{
			for (pair<IClaimer<long>*, int> aP : itsClaimers)
			{
				if (aP.first == theClaimer)
				{
					itsUsedCapacity = itsUsedCapacity - aP.second;
					itsClaimers.remove(aP);
					break;
				}
			}
		}
		double getAvgUse() { return itsUsedCapacity.getAvg(); }
		double getAvg() { return itsCapacity.getAvg(); }
		long setup() { return itsSetup; }
		long setup(int theSetup){ return itsSetup = theSetup; }
		ResourceState state() { return itsState; }
		ResourceState state(ResourceState theState) { return itsState = theState; }
	private:
		ResourceState itsState;
		long itsSetup;
		TimeValue<long> itsCapacity, itsUsedCapacity;
		list<pair<IClaimer<long>*, int>> itsClaimers;
	};

	class ConcreteProcess 
	{
	public:
		long prio;
	private:
		list<Resource*> need = list<Resource*>();

	};

	class Process : public IEntity
	{
	public:
			 
		string name = "processen";
	//private:
		list<ConcreteProcess> itsAlternates = list<ConcreteProcess>();
		list<long> preID = list<long>();
	};

}