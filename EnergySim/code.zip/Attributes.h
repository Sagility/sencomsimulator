#pragma once

#include <iostream>       // std::cout
#include <stack>          // std::stack
#include <vector>         // std::vector
#include <deque>          // std::deque
#include "EnergySim.h"
#include "DateTime.h"
#include "SimEngine.h"
#include "Job.h"
#include <set>
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <type_traits>
#include <functional>
using namespace std;

namespace EnergySim
{
	typedef double(*AttributeFunctionDelegate)(vector<double> arguments);
	class AttributeFunctionHandler
	{
	public:
		static AttributeFunctionDelegate getFunctionByName(string name);
		static double defaultFunction(vector<double> arguments);
		static double memoryswitch(vector<double> arguments);
		static double lookUp(vector<double> arguments);
		static double random(vector<double> arguments);
		static double lessthan(vector<double> arguments);
		static double checkone(vector<double> arguments);
	};
	class AttributeHandler;
	class BaseValue
	{
	public:		BaseValue(){};
				virtual double value() = 0;
				virtual ~BaseValue() {};
				virtual list<BaseValue*>* values()
				{ 
					list<BaseValue* >* aList = new list<BaseValue*>();
					aList->push_back(this);
					return aList;
				}
	};
	class ConstantValue : public BaseValue
	{
		public: ConstantValue(double theValue)
		{
			itsValue = theValue;
		}
		public: double value()
		{
			return itsValue;
		}
		private: double itsValue;
	};
	class AttributeLookUpValue : public BaseValue
	{
		public: AttributeLookUpValue(string theName, AttributeHandler* theHandler)
		{
			itsName = theName;
			itsHandler = theHandler;
		}
		public:  double value();
		private: string itsName;
		private: AttributeHandler* itsHandler;
	};
	class AdditionValue : public BaseValue
	{
		public: AdditionValue(BaseValue* theA, BaseValue* theB)
		{
			itsA = theA;
			itsB = theB;
		}
		public: double value()
		{
			return itsA->value() + itsB->value();
		}
				~AdditionValue() { delete itsA; delete itsB; };
		private: BaseValue *itsA, *itsB;
	};
	class SubstractionValue : public BaseValue
	{
		public: SubstractionValue(BaseValue* theA, BaseValue* theB)
		{
			itsA = theA;
			itsB = theB;
		}
		double value()
		{
			return itsA->value() - itsB->value();
		}
		~SubstractionValue() { delete itsA; delete itsB; };
		private: BaseValue *itsA, *itsB;
	};
	class MultiplicationValue : public BaseValue
	{
		public: MultiplicationValue(BaseValue* theA, BaseValue* theB)
		{
			itsA = theA;
			itsB = theB;
		}
		public: double value()
		{
			return itsA->value() * itsB->value();
		}
				~MultiplicationValue() { delete itsA; delete itsB; };
		private: BaseValue *itsA, *itsB;
	};
	class DivisionValue : public BaseValue
	{
		public: DivisionValue(BaseValue* theA, BaseValue* theB)
		{
			itsA = theA;
			itsB = theB;
		}
		public:  double value()
		{
			return itsA->value() / itsB->value();
		}
				 ~DivisionValue() { delete itsA; delete itsB; };
		private: BaseValue *itsA, *itsB;
	};
	class FunctionValue : public BaseValue
	{
	public:
		FunctionValue(BaseValue* theA, string theFunctionName)
		{
			itsValues = theA;
			myFunc = AttributeFunctionHandler::getFunctionByName(theFunctionName);
		}
		double value()
		{
			vector<double> aVec = vector<double>();
			for (BaseValue* aBV : *(itsValues->values()))
				aVec.push_back(aBV->value());
			return myFunc(aVec);
		}
	private:
		std::function<double(vector<double>)> myFunc;
		BaseValue* itsValues;
	};
	class ListValue : public BaseValue
	{
		public: ListValue(BaseValue* theA, BaseValue* theB)
		{
					itsList.push_back(theA);
					itsList.push_back(theB);
		}
		public: double value()
		{
					return itsList.front()->value();
		}
		list<BaseValue*>* values()
		{
			list<BaseValue*>* aList = new list<BaseValue*>();
			for (BaseValue* aBV : itsList)
				for (BaseValue* bBV : *(aBV->values()))
					aList->push_back(bBV);
			return aList;
		}
		~ListValue() { for (BaseValue* aBV : itsList) delete aBV; };
		private: list<BaseValue*> itsList = list<BaseValue*>();
	};
	
	enum Reporting { Full, Accumulated, None };
	class AttributeReporter;
	class MyParser;
	class BaseAttributeValueHolder
	{
		public: 
		BaseAttributeValueHolder(BaseValue* theBV, string theName)
		{
				itsExpression = theBV;
				itsName = theName;
		}
		bool BaseAttributeValueHolder::operator==(const BaseAttributeValueHolder &other) const
		{
			if (itsExpression==other.itsExpression )
				return true;
			return false;
		}
		//void value(double theValue){ itsNewValue = theValue; }
		double value() { return itsValue; }
		string name() { return itsName; }
		void prepareUpdate(){ itsNewValue = itsExpression->value(); }
		void update(){ itsValue = itsNewValue; }
		void replaceBaseValue(BaseValue* theBV);
		~BaseAttributeValueHolder(){ delete itsExpression; };
		private:  BaseValue* itsExpression;
				  string itsName;
				  double itsNewValue;
				  double itsValue;
				  double itsMin, itsMax, itsTotal;
	};
	class AttributeReporter
	{
		public: 
			AttributeReporter(string theFileName)
			{
				itsFileName = theFileName;
			}
			void startReporting(double theTime)
			{
				if (!itsStarted)
				{
					ofstream file;
					file.open(itsFileName + ".csv", std::ios_base::out);
					file.close();
					itsStarted = true;
				}
				itsTime = theTime;
			}
			void report(BaseAttributeValueHolder* theBAVH)
			{
				itsStr += theBAVH->name() + "\t" + to_string(theBAVH->value()) + "\t" + to_string(itsTime) + "\n";
			}
			void endReporting()
			{
				std::string txt;
				ofstream file;
				file.open(itsFileName + ".csv", std::ios_base::app);
				file << itsStr;
				file.close();
			}
		// void endReport(list<BaseAttributeValue> *theAttributes)
		//{
		//	string txt = "";
		//	ofstream file;
		//	file.open(itsFileName + "_summary.csv", std::ios_base::out);
		//	for(BaseAttributeValue aBAV : *theAttributes)
		//		txt += aBAV.endreport(this);
		//	file << txt;
		//	file.close();
		//}
	private: bool itsStarted = false;
		 std::map<int, double> itsValues =  std::map<int, double>();
		 std::map<int, string> itsLookUp =  std::map<int, string>();
		 std::string itsFileName;
		 std::string itsStr;
		 double itsTime;
	};
	
	class IListenAttributeChange
	{
		public:
			IListenAttributeChange(){};
			virtual void attributeChanged(string theAttribute, double theValue){};
	};
	class AttributeHandler : public IJobStartedListener, public IJobFinishedListener
	{
	public:
		using FunctionPtr = std::add_pointer<void(BaseAttributeValueHolder aBAVH)>::type;
		vector<FunctionPtr> Changed = vector<FunctionPtr>();
	//	vector<IListenAttributeChange*> Changing = vector<IListenAttributeChange*>();
		bool shouldBeUpdated = true;
		double lastUpdateTime = 0;
		double simDelta = 0;
		double lastSimTime = 0;
		double simTime = 0;
		AttributeHandler() { }
		MyParser* itsParser;
		void OnJobStarted(IJob *theJob, EventArgs *theArgs){};
		void OnJobFinished(IJob *theJob, EventArgs *theArgs){};

		list<BaseAttributeValueHolder*> itsAttributes =  list<BaseAttributeValueHolder*>();
		AttributeReporter itsReporter =  AttributeReporter("report");
		bool addAttribute(BaseValue* theAttribute, string theName)
		{
			 itsAttributes.insert(itsAttributes.begin(), new BaseAttributeValueHolder(theAttribute,theName));
			return true;
		}
		bool addAttributeHolder(BaseAttributeValueHolder* theAttributeHolder)
		{
			itsAttributes.insert((itsAttributes.begin()),(theAttributeHolder));
			return true;
		}
		void removeAttribute(string theName)
		{
			for(BaseAttributeValueHolder* aBAV : itsAttributes)
			{
				if (aBAV->name() == theName)
				{
					itsAttributes.remove(aBAV);
					return;
				}
			}
		}
		void replace(string theName, BaseValue* theBV)
		{
			shouldBeUpdated = true;
			for (BaseAttributeValueHolder* aBAV : itsAttributes)
			{
				if (aBAV->name() == theName)
				{
					aBAV->replaceBaseValue(theBV);
					// reportAndUpdateAllAttributes(666);
					return;
				}
			}
			addAttributeHolder( new BaseAttributeValueHolder(theBV,theName));
			//reportAndUpdateAllAttributes(666);
		}
		void removeAllAttributes()
		{
			itsAttributes.clear();
		}
		bool checkAttributes()
		{
			bool aRet = true;
			try
			{
				//reportAndUpdateAllAttributes();
			}
			catch (int e)
			{
				aRet = false;
			}
			return aRet;
		}
		double getAttribute(string theAttributeName)
		{
			for (BaseAttributeValueHolder* aBAV : itsAttributes)
			{
				if (aBAV->name() == theAttributeName)
				{
					return aBAV->value();
				}
			}
			return 0;
		}
		string getAllAttributes()
		{
			updateAllAttributes();
			updateAllAttributes();
			string aStr = "";
			for (BaseAttributeValueHolder* aBAV : itsAttributes)
			{
				aStr += aBAV->name() + "\t" + std::to_string(aBAV->value()) + "\n";
			}
			return aStr;
		}
		void updateSimVariabels(double time)
		 {
			lastSimTime = simTime;
			simTime = time;
			simDelta = simTime - lastSimTime;
			replace("simtime",   new ConstantValue(simTime));
			replace("simdelta",  new ConstantValue(simDelta));
			reportAllAttributes(time);
		 }
		void reportAllAttributes(double time)
		 {
			 itsReporter.startReporting(time);
			 for (BaseAttributeValueHolder* aBAV : itsAttributes)
			 {
				 itsReporter.report(aBAV);
			 }
			 itsReporter.endReporting();
		}
		void updateAllAttributes()
		 {
			 for (BaseAttributeValueHolder* aBAV : itsAttributes)
			 	aBAV->prepareUpdate();
			 for (BaseAttributeValueHolder* aBAV : itsAttributes)
				 aBAV->update();
			 publishUpdates();
		 }
		void reportAllAttributes()
		 {
			 //itsReporter.
			publishUpdates();
		 }
		void publishUpdates()
		 {
			if (Changed.size()>0)
			{
				for(BaseAttributeValueHolder* aBAV : itsAttributes)
					for (FunctionPtr aFPtr : Changed)
						aFPtr(*aBAV);
			}
		 }
		void end()
		 {
			// itsReporter.endReport(&itsAttributes);
		 }
	};
}