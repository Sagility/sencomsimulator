// DateTime.h

#pragma once
#include <iostream>
#include <string>
#include <stdio.h>
#include <time.h>


namespace EnergySim {


	class ENERGYSIM_DLL_PUBLIC DateTime{
	public:
		// Get current date/time, format is DD_MM_YYYY_HH_mm_ss
		static const std::string currentDateTime() 
		{

			struct tm timeinfo;
			char       buf[80];
			time_t     now = time(0);
#ifdef STDC

			tstruct = *localtime(&now);

			// Visit http://en.cppreference.com/w/cpp/chrono/c/strftime
			// for more information about date/time format
			strftime(buf, sizeof(buf), "%d-%m-%Y.%X", &timeinfo);
#else
			localtime_s(&timeinfo, &now); 
			strftime(buf, sizeof(buf), "%d_%m_%Y_%H_%M_%S", &timeinfo);

#endif
			return buf;
		};
	};
}