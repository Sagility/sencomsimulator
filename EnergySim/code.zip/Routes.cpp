#include "stdafx.h"
#include "Routes.h"

using namespace std;

namespace EnergySim
{
	list<WaitForPreReqDoneJob*> PreReqs::itsWaiters = list<WaitForPreReqDoneJob*>();
	list<long> PreReqs::itsDonePreReqs = list<long>();
	bool PreReqs::canIStart(WaitForPreReqDoneJob* theJob)
	{
		// Check if prerequisites fulfilled, call Finishtep on RouteFollower
		for (long aID : theJob->itsPreReqs)
		{
			bool aFound = false;
			for (long bID : itsDonePreReqs)
			{
				if (aID == bID)
				{
					aFound = true;
					break;
				}
			}
			if (!aFound)
				return false;
		}
		return true;
	}
	bool PreReqs::startWaiters()
	{
		for (WaitForPreReqDoneJob* aJob : itsWaiters)
		{
			if (canIStart(aJob))
			{
				itsWaiters.remove(aJob);
				aJob->Finish();
				return true;
			}
		}
		return false;
	}
	void WaitForPreReqDoneJob::Execute()
	{
		NotifyJobStarted();
		PreReqs::wait(this);
	}
}