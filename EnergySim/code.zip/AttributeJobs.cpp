// EnergySimtest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<iostream>
#include "SimLogEnvironment.h"
#include "EnergySim.h"
#include "SimEngine.h"
#include "CombinedJobController.h"
#include "LogJob.h"
#include "DelayJob.h";
#include "ClaimRelease.h"
//#include "Parsing.h"
#include "AttributeJobs.h"

namespace EnergySim
{

}