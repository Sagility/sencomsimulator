#pragma once

#include <iostream>       // std::cout
#include <stack>          // std::stack
#include <vector>         // std::vector
#include <deque>          // std::deque
#include "EnergySim.h"
#include "DateTime.h"
#include "SimEngine.h"
#include "Job.h"
#include <set>
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <type_traits>
#include <functional>
#include "Parsing.h"
#include "Attributes.h"
using namespace std;

namespace EnergySim
{
	/*
		Job requires resources

		start job if all other job started
	
		job har pre-req jobs

		Job kan starta om pre-req jobb gjorda.
		Inget ostartad jobb f�re detta job anv�nder n�gon resurs som detta jobb anv�nder.
		(modifieran av ovan, man kan markera resurser som det �r OK att starta)
	
	*/
	class Schedule;
	class WaitForScheduleJob;
	struct SchedElement
	{
	public:
		SchedElement(long a, long b, long c)
		{
			lotID = a;
			stepID = b;
			time = c;
		}
		long lotID;
		long stepID;
		long time;
		long processID;
		long processModeID;
	};
	class Schedule
	{
	private: vector<SchedElement*>* itsInSchedule = new vector<SchedElement*>();
	private: vector<pair<double, pair<long, long>>> *itsOutSchedule = new vector<pair<double, pair<long, long>>>();
	public: vector<WaitForScheduleJob*> *itsWaiters = new vector<WaitForScheduleJob*>();
	private: string itsName = "";
	private: SimContext itsContext = SimContext();
	public: 
		Schedule(string theName, SimContext theContext)
		{
			itsName = theName;
			itsContext = theContext;
		}
		void finish()
		{
			string line = "";
		//	using (System.IO.StreamWriter file = new System.IO.StreamWriter(itsName + ".outschedul"))
			{

				for(pair<double, pair<long, long>> p : *itsOutSchedule)
				{
				//	line = p.first().ToString() + " " + p.Value.Value.ToString() + " " + p.Key.ToString();
					//file.WriteLine(line);
				}
			}
		}
		// M�ste synca med claim and release, eller kanske inte
		void addJob(long lotID, long stepID, long time)
		{
			itsInSchedule->push_back(new SchedElement(lotID, stepID, time));
		}
		void markJobAsStarted(long lotID, long stepID);
		bool canIStart(long lotID, long stepID)
		{
			// Does the number exist in the schedule. if not it can start
			// If it exists in the schedule, is it the first one, then it can start
			// Otherwise it can not start
			pair<long, long> *aJob = new pair<long, long>(lotID, stepID);
			for(SchedElement *aSE : *itsInSchedule)
			{
				long firstTime = itsInSchedule->front()->time;
				if (aJob->first == aSE->lotID)
					if (aJob->second == aSE->stepID)
					{
						SchedElement* bSE = itsInSchedule->front();
						if (aJob->first == bSE->lotID)
							if (aJob->second == bSE->stepID)
								return true;
						if (aSE->time - firstTime < 10)
							return true;
						// Look for resource need

						return false;
					}
			}
			return true;
		}
	};
	class PublishScheduleJob : public IJob
	{
		public: 
			long itsLotID, itsStepID;
			Schedule* itsSchedule;
			PublishScheduleJob(Schedule* theSchedule, long theLotID, long theStepID)
			{
				itsLotID = theLotID;
				itsStepID = theStepID;
				itsSchedule = theSchedule;
			}
			virtual void Execute()
			{
				NotifyJobStarted();
				itsSchedule->markJobAsStarted(itsLotID, itsStepID);
				NotifyJobFinished();
			}
			virtual void Dispose() { }
	};
	class WaitForScheduleJob : public IJob
	{
		public:
			long itsLotID, itsStepID;
			Schedule* itsSchedule;
			WaitForScheduleJob(Schedule* theSchedule, long theLotID, long theStepID)
			{
				itsLotID = theLotID;
				itsStepID = theStepID;
				itsSchedule = theSchedule;
			}
			virtual void Execute()
			{
				NotifyJobStarted();
				if (itsSchedule->canIStart(itsLotID, itsStepID))
				{
					finish();
					return;
				}
				itsSchedule->itsWaiters->push_back(this);
			}
			void finish()
			{
				NotifyJobFinished();
			}
			virtual void Dispose() { }
	};
}