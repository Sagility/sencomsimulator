#pragma once
//using System;
//using System.IO;
//using System.Text.RegularExpressions;
#include <iostream>       // std::cout
#include <stack>          // std::stack
#include <vector>         // std::vector
#include <deque>          // std::deque
#include "EnergySim.h"
#include "DateTime.h"
#include "SimEngine.h"
#include "Job.h"
#include <set>
#include "CombinedJobController.h"
#include "LogJob.h"
#include "DelayJob.h"
#include "ClaimRelease.h"
#include "Attributes.h"
#include "Parsing.h"
#include "AttributeJobs.h"
#include "Schedule.h"
#include "Routes.h"
using namespace std;


namespace EnergySim_NameConstants
{
	const std::string DELAYSTEP = "DELAY";						// Time
	const std::string WAIT_ATTRIBUTE_STEP = "WAIT_ATTRIBUTE";			// ID, v�rde
	const std::string PUBLISH_ATTRIBUTE_STEP = "SET_ATTRIBUTE";		//
	const std::string PUBLISH_ROUTEFOLLOWER_TO_ATTRIBUTE_STEP = "SET_ATTRIBUTE_FROM_LOT";
	const std::string WAIT_SCHEDULE_STEP = "WAIT_SCHEDULE";
	const std::string PUBLISH_SCHEDULE_STEP = "PUBLISH_SCHEDULE";
	const std::string WAIT_PREREQ_STEP = "WAIT_PREREQ";
	const std::string PUBLISH_PREREQ_STEP = "PUBLISH_PREREQ";
	const std::string GET_STEP = "GET";
	const std::string FREE_STEP = "FREE";
	const std::string STATE_SET = "SET_STATE";
	const std::string WAIT_SETUP_STEP = "SETUP";
	const std::string LOGSTEP = "LOG";
	const std::string EVENTSTEP = "EVENT";
}

namespace EnergySim
{
	class Route;
	class Buffer;
	class Process;
	class BufferDemand;
	class Order;
	class Schedule;
	class WaitForScheduleJob;
	class SimContext;

	/*
	Routefiles
	Resourcefiles
	Orderfiles
	Schedulefile
	Prereqfile
	*/

	class TokenListner
	{
		public:
			virtual void gotInt(long aL);
			virtual void gotDouble();
			virtual void gotBool();
			virtual void gotString();
			virtual void getEnd();
	};
	class LyssnaPaDem
	{
	
	
	
	
	};




	class FileReader
	{

		

	};
	
	class SimAdmin
	{
	public:
		 list<Route*> *itsRoutes = new list<Route*>();
		 list<Order*> *itsOrders = new list<Order*>();
		 map<long, long> *itsRes = new map<long, long>();
		 list<Buffer*> *itsBuffers = new list<Buffer*>();
		 list<Process*> *itsProcess = new list<Process*>();
		 list<BufferDemand*> *itsDemands = new list<BufferDemand*>();
		 AttributeHandler *itsHandler;
		 SimContext *Context;
		 Schedule *aScheduler;
		 bool createModel(string basename)
		{
			itsHandler = new AttributeHandler();
			Context = new SimContext();
			aScheduler = new Schedule(basename, *Context);
			readModel(basename);
			return true;
		}

		long runModel();
		void readModel(string basename)
		{
			readResources(basename + ".resource");
			readRoutes(basename);
			readOrders(basename + ".order");
			readFunctionAttributes(basename + ".function");
			readExpressionAttributes(basename + ".expression");
			readSchedule(basename + ".sched");
		//	readBuffers(basename + ".buffer");
		//	readProcess(basename + ".process");
		//	readDemand(basename + ".demand");
		}
		Buffer* getBufferByID(long id);
		string generateProcessUsage();
		void readDemand(string filename);
		void readProcess(string filename);
		void readBuffers(string filename);	
		void readOrders(string filename);
		void readResources(string filename);
		void readRoutes(string filename);
		void readRoute(string filename, string theName);
		void readFunctionAttributes(string filename);
		void readExpressionAttributes(string filename);
		void readSchedule(string filename);
	};

	

	class Step
	{
		// Get, free delay, Setattribute, waitattribute
		protected: long itsID;
		protected: SimContext* itsContext;
		public: void generateJobs(Schedule* theS, CombinedJobController theController, long lotID);
		public: virtual void generateSpecificJobs(CombinedJobController theController)  {     }
	};

	class ENERGYSIM_DLL_PUBLIC StepReader
	{
		// Reads a line and creates the correct step with the right parameters,
		// the step itself creates the jobs when given an CombinedJobController
		// OR instead of a CJC can we send a RouteFollower
		public:
			Step* readLine(string str);
			SimContext* itsCtx;
			AttributeHandler* itsHandler;
			Schedule* itsSchedule;
		private:
			Step* translateToStep(list<string> arg);
	};
	class DelayStep : public Step
	{
		long itsDelay;
	public: DelayStep(long theDelay, long theID, SimContext* theContext)
		{
			itsDelay = theDelay;
			itsID = theID;
			itsContext = theContext;
		}
	public:  void generateSpecificJobs(CombinedJobController theController)
		{
			theController.AddJob(new DelayJob(itsContext, (int)itsDelay));
		}
	};
	class GetStep : public Step
	{
		long itsRes;
	public: GetStep(long theRes, long theID, SimContext* theContext)
		{
			itsRes = theRes;
			itsID = theID;
			itsContext = theContext;
		}
	public: void generateSpecificJobs(CombinedJobController theController)
		{
			theController.AddJob(new ClaimJob<long>(NULL,itsRes));
		}
	};
	class FreeStep : public Step
	{
		long itsRes;
	public: FreeStep(long theRes, long theID, SimContext* theContext)
		{
			itsRes = theRes;
			itsID = theID;
			itsContext = theContext;
		}
	public: void generateSpecificJobs(CombinedJobController theController)
		{
				theController.AddJob(new ReleaseJob<long>(itsContext, itsRes));
		}
	};
	class SetStep : public Step
	{
		double itsValue;
		string itsAttribute;
		AttributeHandler* itsHandler;
	public: SetStep(string theAttribute, double theValue, long theID, AttributeHandler* theHandler, SimContext* theContext)
		{
			itsValue = theValue;
			itsAttribute = theAttribute;
			itsID = theID;
			itsHandler = theHandler;
			itsContext = theContext;
		}
	public: void generateSpecificJobs(CombinedJobController theController)
		{
			theController.AddJob(new SetAttributeJob(itsHandler, itsAttribute, itsValue));
		}
	};
	class WaitStep : public Step
	{
		double itsLowValue, itsHighValue;
		string itsAttribute;
		AttributeHandler* itsHandler;
	public: WaitStep(string theAttribute, double theLowValue, double theHighValue, long theID, AttributeHandler* theHandler, SimContext* theContext)
		{
			itsLowValue = theLowValue;
			itsHighValue = theHighValue;
			itsAttribute = theAttribute;
			itsID = theID;
			itsHandler = theHandler;
			itsContext = theContext;
		}
	public: void generateSpecificJobs(CombinedJobController theController)
		{
			theController.AddJob(new WaitForAttributeJob(itsHandler, itsAttribute, itsLowValue, itsHighValue));
		}
	};
	class LogStep : public Step
	{
			double itsValue;
			string itsMsg;
		public: LogStep(string theMsg, long theID,  SimContext* theContext)
		{
			itsMsg = theMsg;
			itsID = theID;
			itsContext = theContext;
		}
		public: void generateSpecificJobs(CombinedJobController theController)
		{
			theController.AddJob(new LogJob(itsContext, itsMsg));
		}
	};
	class PublishPreReqDoneStep : public Step
	{
			long itsPreReqDone;
			string itsMsg;
		public: PublishPreReqDoneStep(long thePreReq, long theID, SimContext* theContext)
		{
			itsPreReqDone = thePreReq;
			itsID = theID;
			itsContext = theContext;
		}
		public: void generateSpecificJobs(CombinedJobController theController);
	};
	class WaitForPreReqDoneStep : public Step
	{
		list<long> itsPreReqNeed;
		public: WaitForPreReqDoneStep(list<long> thePreReq, long theID, SimContext* theContext)
		{
			itsPreReqNeed = thePreReq;
			itsID = theID;
			itsContext = theContext;
		}
		public: void generateSpecificJobs(CombinedJobController theController);
	};
	class WaitForScheduleStep : public Step
	{
		long itsLotID,itsStepID;
		Schedule* itsSchedule;
	public: WaitForScheduleStep(long theLotID, long theStepID, long theID, SimContext* theContext, Schedule* theSchedule)
	{
		itsLotID = theLotID;
		itsStepID = theStepID;
		itsID = theID;
		itsContext = theContext;
		itsSchedule = theSchedule;
	}
	public: void generateSpecificJobs(CombinedJobController theController);
	};
	class PublishScheduleStep : public Step
	{
		long itsLotID, itsStepID;
		Schedule* itsSchedule;
	public: PublishScheduleStep(long theLotID, long theStepID, long theID, SimContext* theContext, Schedule* theSchedule)
	{
		itsLotID = theLotID;
		itsStepID = theStepID;
		itsID = theID;
		itsContext = theContext;
		itsSchedule = theSchedule;
	}
	public: void generateSpecificJobs(CombinedJobController theController);
	};

	#include "EnergySim.h"
	struct Order
	{
	public:
		 long ID;
		 long Time;
		 string Route;
		 long stepID;
		 list<long> preReqs;
	}; 
	class Route
	{
		long ID;
		public: string name = "";
		private: vector<Step*> itsSteps =  vector<Step*>();
		public: void addStep(Step* theStep)
		{
			itsSteps.push_back(theStep);
		}
		public: void createThisJobOrder(Schedule* theS, Order aOrder, CombinedJobController cj1)
		{
			cj1.AddJob(new DelayJob(cj1.context(), (int)aOrder.Time * 1000));
			cj1.ID( aOrder.ID);
			for(Step* s : itsSteps)
				s->generateJobs(theS, cj1, aOrder.ID);
		}
	};

}