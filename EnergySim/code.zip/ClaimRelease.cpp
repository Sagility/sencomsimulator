#include "Stdafx.h"
#include "ClaimRelease.h"


namespace EnergySim
{
	

}