#pragma once

#include <iostream>       // std::cout
#include <stack>          // std::stack
#include <vector>         // std::vector
#include <deque>          // std::deque
#include "EnergySim.h"
#include "DateTime.h"
#include "SimEngine.h"
#include "Job.h"
#include <set>
using namespace std;

namespace EnergySim
{
	class BaseValue;
	class BaseAttributeValueHolder;
	class AttributeHandler;
	enum Function
	{
		EMPTY,
		ADD,
		SUB,
		MUL,
		DIV,
		LP,
		RP,
		COMMA,
		NAME,
		VALUE
	};
	struct MyParserAction
	{
	public:
		Function itsFunction;
		BaseValue* itsBV;
		string itsValue;
	};
	class ENERGYSIM_DLL_PUBLIC MyParser
	{
	public:
		MyParser();
		MyParser(AttributeHandler* theHandler);
		void Tokenize();
		void test(string aStr);
		void addAttribute(string theExpression, string theName);
		BaseAttributeValueHolder* parse(string theExpression, string theName);
		AttributeHandler* aAH = NULL;
	private:
		string itsStr;
		void Parse();
		void popOneAction();
		bool next(Function theF);
		std::stack<MyParserAction> src = std::stack<MyParserAction>();
		std::stack<MyParserAction> dst = std::stack<MyParserAction>();
		std::stack<MyParserAction> func = std::stack<MyParserAction>();
	};
}