#pragma once

#include <vector>
#include <map>
#include <algorithm>
#include <sstream>
#include "config.h"
#include "Job.h"
#include "SimEngineTimer.h"
#include "TimeValues.h"
#include <list>
#include "Entity.h"
#include "SimAdmin.h"

using namespace std;

namespace EnergySim {
	
	class Step;
	class IRoute
	{
		public:
			list<Step*>::iterator  getIterator(){ return itsSteps.begin(); }
		private:
			list<Step*> itsSteps;
	};


	// Order - RouteFollower - CombinedJobController      : Resources

	class Resource;


	class IRouteFollower : public IEntity, public IJobFinishedListener
	{
		public:
			void nextStep();
			IRouteFollower(string route);
		protected:
			SimContext* itsSimContext;
			list<Resource*> itsRoutes;
			IRoute* itsRoute;
			Step* itsCurrentStep;
			list<Step>::const_iterator itsStepI;
			CombinedJobController* itsCJC;
	};

	class OperationDoer : public IRouteFollower
	{
		public: 
			OperationDoer(string route, list<long> preReqs, long id);
			long itsID;
			list<long> itsNeededPreReqs;
	};
	class WaitForPreReqDoneJob : public IJob, public IListenAttributeChange
	{
	public:
		list<long> itsPreReqs;
		WaitForPreReqDoneJob(list<long> thePreReqs)
		{
			itsPreReqs = thePreReqs;
		}
		virtual void Execute();
		virtual void Dispose() { }
	};
	class PreReqs
	{
	public:
		static void wait(WaitForPreReqDoneJob* theJob) { itsWaiters.push_back(theJob);  while (startWaiters()); }
		static void done(long theDone) { itsDonePreReqs.push_back(theDone); while (startWaiters()); };
	private:
		static bool canIStart(WaitForPreReqDoneJob* theJob);
		static bool startWaiters();
		static list<WaitForPreReqDoneJob*> itsWaiters;
		static list<long> itsDonePreReqs;
	};
	class PublishPreReqDone : public IJob
	{
	public:
		long itsPreReqID;
		PublishPreReqDone(long thePreReqID)
		{
			itsPreReqID = thePreReqID;
		}
		virtual void Execute()
		{
			NotifyJobStarted();
			PreReqs::done(itsPreReqID);
			NotifyJobFinished();
		}
		virtual void Dispose() { }
	};


}