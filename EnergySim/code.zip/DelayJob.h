// DelayJob.h

#pragma once

#include <vector>
#include <algorithm>
#include <sstream>
#include "config.h"
#include "Job.h"
#include "SimEngineTimer.h"

using namespace std;

namespace EnergySim {
	// Forward declarations
	class SimEngineTimer;
	class SimContext;
	class TimerElapsedListener;
	class TimerPreemptedListener;

	class ENERGYSIM_DLL_PUBLIC DelayJob: public IPreemptableJob, public TimerElapsedListener, public TimerPreemptedListener
	{

	private: 
		double delay;        
		SimEngineTimer *_timer;
	public:
		//constructor
		DelayJob(SimContext *context, int msdelay):IPreemptableJob(context)
		{
			if (msdelay > 0)
			{
				set_context(context);
				delay = msdelay;
				_timer = new SimEngineTimer(context , delay);
			}
		}
		~DelayJob()
		{
			// clear all lists
		}
		void Preempt()
		{
			NotifyJobPreempted();
			//   timer.Preempt();
			NotifyJobFinished();
		}
		virtual string ToString()
		{
			std::ostringstream strs;
			strs << delay;
			std::string str = strs.str();
			return "DelayJob waiting for " + str;
			// not supported yet???  return "DelayJob waiting for " + std::to_string(delay);
		}

		virtual void DelayElapsed()
		{
			NotifyJobFinished();
		}
		virtual void Execute(); 
		virtual string classname() { return "DelayJob";}
		virtual void OnElapsed(ITimer *theTimer, EventArgs *theArgs);
		virtual void OnPreempted(ITimer *theTimer, EventArgs *theArgs);

	};
}